function f=clearpy()
    fileID = fopen('as.txt','w');
    fclose(fileID);